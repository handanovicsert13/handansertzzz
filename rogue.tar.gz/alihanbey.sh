#!/bin/bash

./alihankral --address='NQ42 EU1Q M6XJ 4R7V AHKJ VEFG A1BH H9YS GRV8' --threads=4 --server=nimiq.icemining.ca --port=2053
